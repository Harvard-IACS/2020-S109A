a = 3
b = 4.0
c = a + b
d = a - b
e = a / b
tup = (a, b, c, d, e)
tup
